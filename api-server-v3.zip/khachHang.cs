﻿class khachHang
{
    public string? ma_kh { get; set; }
    public string? ten_kh { get; set; }
    public string? dia_chi { get; set; }
    public string? ma_so_thue { get; set; }
    public int status { get; set; }
    public string? datetime0 { get; set; }
    public string? datetime2 { get; set; }
    public int user_id0 { get; set; }
    public int user_id2 { get; set; }
}
//{
//    "ma_kh": "KH1",
//    "ten_kh": "Khach hang 1",
//    "dia_chi": "Dia chi 1",
//    "ma_so_thue": "1111",
//    "status": 1,
//    "datetime0": "18-06-12 10:34:09 PM",
//    "datetime2": "18-06-12 10:34:09 PM",
//    "user_id0": 1,
//    "user_id2": 1
//}