using Microsoft.EntityFrameworkCore;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Net.Http;
using Newtonsoft.Json;
using apiTokenInfo;
using System.Web.Http.Cors;
using System.Web.Http;

var MyAllowSpecificOrigins = "_myAllowSpecificOrigins";
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddCors(options =>
{
    options.AddPolicy(name: MyAllowSpecificOrigins,
                      policy =>
                      {
                          policy.WithOrigins("*")
                          .AllowAnyHeader()
                          .AllowAnyMethod();
                      });
});
// services.AddResponseCaching();

builder.Services.AddControllers();
var app = builder.Build();
app.UseCors(MyAllowSpecificOrigins);

static ApiTokenInfo LoginToKeyCloak(user InputUser,string apiUrl)
{
    //bypass ssl
    HttpClientHandler clientHandler = new HttpClientHandler();
    clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };

    // Pass the handler to httpclient(from you are calling api)
    HttpClient client = new HttpClient(clientHandler);

    client.DefaultRequestHeaders.Accept.Clear();
    client.DefaultRequestHeaders.Accept.Add(
        new MediaTypeWithQualityHeaderValue("application/vnd.github.v3+json"));
    client.DefaultRequestHeaders.Add("User-Agent", ".NET Foundation Repository Reporter");
    //Them data vao body
    var dict = new Dictionary<string, string>();
    dict.Add("username", ""+InputUser.username);
    dict.Add("password", ""+InputUser.password);
    dict.Add("grant_type", "password");
    dict.Add("client_id", "arito");
    var content = new FormUrlEncodedContent(dict);
    //post
    var response = Task.Run(() => client.PostAsync(apiUrl, content));
    response.Wait();
    var result = response.Result.Content.ReadAsStringAsync().GetAwaiter().GetResult();
    //parse result to object
    var token_info = ApiTokenInfo.FromJson(result);
    return token_info;
}


app.MapGet("/health", () =>
{
    return "Health is good";
});

app.MapPost("/login", async (user InputUser) =>
{
    string url = "https://key.arito.vn:4433/realms/master/protocol/openid-connect/token";

    ApiTokenInfo token_info =  LoginToKeyCloak(InputUser, url);
    var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(token_info);
    return jsonString;
});
app.MapGet("/connect-to-db", () =>
{
    //db _db = new db();
    //_db.ThemKhachHang("insert into dmkh(ma_kh, ten_kh, dia_chi, ma_so_thue, status, datetime0, datetime2, user_id0, user_id2) values('KH22', 'duyv22', 'dia chi 22', '2200', 1, convert(datetime, '18-06-12 10:34:09 PM', 5), convert(datetime, '18-06-12 10:34:09 PM', 5), 1, 1)");
    //_db.XoaKhachHang("delete from dmkh where ma_kh = 'KH5'");
     return "Dang thuc thi sql";
});
app.MapGet("/lay-danh-sach-khach-hang", () =>
{
    db _db = new db();
    return _db.LayKhachHang("select * from dmkh");
});
app.MapPost("/xoa-khach-hang", async (khachHang bodyKhachHang) =>
{
    db _db = new db();
    Console.WriteLine("delete " + bodyKhachHang.ma_kh);
    _db.XoaKhachHang($"delete from dmkh where ma_kh = '{bodyKhachHang.ma_kh}'");
    return "1";
});
app.MapPost("/them-khach-hang", async (khachHang bodyKhachHang) =>
{
    db _db = new db();
    Console.WriteLine("them " + bodyKhachHang.ma_kh);
    _db.ThemKhachHang($"insert into dmkh(ma_kh, ten_kh, dia_chi, ma_so_thue, status, datetime0, datetime2, user_id0, user_id2) values('{bodyKhachHang.ma_kh}', '{bodyKhachHang.ten_kh}', '{bodyKhachHang.dia_chi}', '{bodyKhachHang.ma_so_thue}', {bodyKhachHang.status.ToString()}, convert(datetime, '{bodyKhachHang.datetime0}', 5), convert(datetime, '{bodyKhachHang.datetime0}', 5), 1, 1)");
    return "1";
});

app.Run();